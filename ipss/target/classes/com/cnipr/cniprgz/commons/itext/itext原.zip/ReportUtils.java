package com.cnipr.cniprgz.commons.itext;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import org.junit.Test;

import com.google.common.collect.Lists;
import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.rtf.RtfWriter2;

public class ReportUtils {

	public String write(String reportName,String descPath,List<ReportBean> list){
		Document document = null;
		try {
			File file = new File(descPath,reportName);
			document = openFile(file);
			if(list!=null && list.size()>0){
				for(ReportBean bean : list){
					document.add(ReportTemplates.getInstance().getDefaultParagraph(bean.getTitle()));
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			if(document!=null){
				document.close();
				document = null;
			}
		}
		return reportName;
	}
	
	/**
	 * 打开文档
	 * @param file
	 * @return document
	 */
	public Document openFile(File file) throws FileNotFoundException{ 
		Document document = new Document(PageSize.A4);
		//建立一个书写器(Writer)与document对象关联，通过书写器(Writer)可以将文档写入到磁盘中
		RtfWriter2.getInstance(document,new FileOutputStream(file));
		//设置边距 左，右，上，下
		document.setMargins(90, 90, 72, 72);
		
		document.open();
		return document;
	}
	
	
	@Test
	public void writeTest(){
		ReportUtils reportUtils = new ReportUtils();
		List<ReportBean> list = Lists.newArrayList();
		ReportBean bean = new ReportBean();
		bean.setTitle("第一个测试报告");
		list.add(bean);
		reportUtils.write("测试报告.doc", "D:/", list);
		
	}
}
