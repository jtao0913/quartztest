package com.cnipr.cniprgz.commons.itext;

import java.awt.Color;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import net.jbase.common.util.FileUtil;
import net.jbase.common.util.StringUtil;

import com.cnipr.cniprgz.commons.DataAccess;
import com.cnipr.cniprgz.commons.PathUtil;
import com.cnipr.cniprgz.commons.Util;
import com.cnipr.cniprgz.func.download.JspFileDownload;
import com.cnipr.corebiz.search.entity.LegalStatusInfo;
import com.cnipr.corebiz.search.entity.PatentInfo;
import com.cnipr.corebiz.search.entity.YzwsInfo;
import com.cnipr.corebiz.search.ws.response.DetailSearchResponse;
import com.lowagie.text.Chapter;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Section;
import com.lowagie.text.Table;

public class PatentInfoPDFCreater {
	
	private final String br = "\r\n";
	private final String space  = "　 　  ";
	private  Font normalFont = ITextFontUtil.getCnFont(14, Color.black);
	private  Font titleFont16 = ITextFontUtil.getCnBoldFont(16, Color.BLACK);
	private  Font titleFont14 = ITextFontUtil.getCnBoldFont(14, Color.BLACK); 
	private  PatentInfo patentInfo =  null;
	private  PdfBean pdfBean ;
	private  List elementList;
	private  String dbName ;//专利所在库名
	private  String pdfTempPath;
	 /**
	  * 插入pdf摘要
	  * */ 
	public void insertZhaiyao(PatentInfo patentInfo, List elementList ,String imageZhaiYaoURL ){		
		   String zhaiyao =   br + space + patentInfo.getAb() + br ;
		   Image img = null ;
		   if(StringUtil.hasText(imageZhaiYaoURL))
		   {
			   img = PdfUtil.getImage(imageZhaiYaoURL, Image.LEFT, -1, -1);
			   img.scaleToFit(400, 400);
		   }
		   Phrase zhaiyaoTitle  =PdfUtil.getPhrase(br+"摘要：" , titleFont14); 
		   Paragraph zhaiyaoPara  =PdfUtil.getPara(zhaiyao  , normalFont); 
		   elementList.add(zhaiyaoTitle);
		   elementList.add(zhaiyaoPara); 
		   if(img!=null)
			   elementList.add(img);
	}
	
	/**
	 * 引证文献
	 * 
	 */
	public void insertYZWX(DetailSearchResponse detailResponse ,  List elementList){
		 // 审查员引证专利文献
		  List<YzwsInfo> scyyzzlList = detailResponse.getScyyzzlList(); 
		// 审查员引证非专利文献
		  List<YzwsInfo> scyyzfzlList = detailResponse.getScyyzfzlList();
		// 申请人引证专利文献
		  List<YzwsInfo> sqryzzlList = detailResponse.getSqryzzlList() ;
		// 审查员被引证专利文献
		  List<YzwsInfo> scybyzzlList = detailResponse.getScybyzzlList();
		// 申请人被引证专利文献
		  List<YzwsInfo> sqrbyzzlList = detailResponse.getSqrbyzzlList();
		  
		  /*引证文献*/ 
		   Paragraph yinzhengwenxianPara = null;
		   if (scyyzzlList == null && scyyzfzlList == null && sqryzzlList == null
					&& scybyzzlList == null && sqrbyzzlList == null) {
			   	 yinzhengwenxianPara = PdfUtil.getPara (br+"该专利无引证信息"+br , titleFont14); 
			   	 elementList.add(yinzhengwenxianPara);
			}else
			{
				if (scyyzzlList != null && scyyzzlList.size() > 0) {//审查员引证专利文献  
					//表格
					   TableBean tableBean = new TableBean();
					   tableBean.setColumns(3);
					   List<String> thList = new ArrayList<String>();
					   thList.add("被引证文献原始数据");
					   thList.add("被引证文献专利号");
					   thList.add("被引证文献公布日");
					   Font thFont = ITextFontUtil.getCnBoldFont(14, Color.BLACK);
					   tableBean.setThList(thList);  
					  
							   //表格数据
							   List<List> bodyList = new ArrayList<List>(); //所有数据
							   List rowList = null; //行数据
							   for (YzwsInfo yzwx : scyyzzlList) {
							    rowList = new ArrayList();
							    rowList.add(yzwx.getStrBaseData());
							    rowList.add(yzwx.getStrGBH());
							    rowList.add(yzwx.getStrGBRQ());
							    bodyList.add(rowList);
							   }
					    
					   tableBean.setBodyList(bodyList);
					   Font bodyFont = ITextFontUtil.getCnFont(12, Color.BLACK);						  
					   Table table = PdfUtil.getTable(tableBean, thFont, bodyFont);  
					    elementList.add(PdfUtil.getPara ("审查员引证专利文献" , titleFont14)); 
						elementList.add(table);
				}
				if (scyyzfzlList != null && scyyzfzlList.size() > 0) {//审查员引证非专利文献
					//表格
					   TableBean tableBean = new TableBean();
					   tableBean.setColumns(1);
					   List<String> thList = new ArrayList<String>();
					   thList.add("被引证文献原始数据"); 
					   Font thFont = ITextFontUtil.getCnBoldFont(14, Color.BLACK);
					   tableBean.setThList(thList);  						  
							   //表格数据
							   List<List> bodyList = new ArrayList<List>(); //所有数据
							   List rowList = null; //行数据
							   for (YzwsInfo fyzwx : scyyzfzlList) {
							    rowList = new ArrayList();
							    rowList.add( fyzwx.getStrBaseData()); 
							    bodyList.add(rowList);
							   }						    
					   tableBean.setBodyList(bodyList);
					   Font bodyFont = ITextFontUtil.getCnFont(12, Color.BLACK);						  
					   Table table = PdfUtil.getTable(tableBean, thFont, bodyFont);  
					    elementList.add(PdfUtil.getPara ("审查员引证非专利文献" , titleFont14)); 
						elementList.add(table);
				}
				if (sqryzzlList != null && sqryzzlList.size() > 0) {//申请人引证专利文献
					//表格
					   TableBean tableBean = new TableBean();
					   tableBean.setColumns(3);
					   List<String> thList = new ArrayList<String>();
					   thList.add("被引证文献原始数据");
					   thList.add("被引证文献专利号");
					   thList.add("被引证文献公布日");
					   Font thFont = ITextFontUtil.getCnBoldFont(14, Color.BLACK);
					   tableBean.setThList(thList);  
					  
							   //表格数据
							   List<List> bodyList = new ArrayList<List>(); //所有数据
							   List rowList = null; //行数据
							   for (YzwsInfo byzwx : sqryzzlList)  {
							    rowList = new ArrayList();
							    rowList.add(byzwx.getStrBaseData());
							    rowList.add(byzwx.getStrGBH());
							    rowList.add(byzwx.getStrGBRQ());
							    bodyList.add(rowList);
							   } 
					   tableBean.setBodyList(bodyList);
					   Font bodyFont = ITextFontUtil.getCnFont(12, Color.BLACK);						  
					   Table table = PdfUtil.getTable(tableBean, thFont, bodyFont);  
					    elementList.add(PdfUtil.getPara ("申请人引证专利文献" , titleFont14)); 
						elementList.add(table);
				}
				if (scybyzzlList != null && scybyzzlList.size() > 0
						|| sqrbyzzlList != null && sqrbyzzlList.size() > 0) // 被引证文献
				{
					//表格
					   TableBean tableBean = new TableBean();
					   tableBean.setColumns(2);
					   List<String> thList = new ArrayList<String>();
					   thList.add("审查员被引证专利");
					   thList.add("申请人被引证专利"); 
					   Font thFont = ITextFontUtil.getCnBoldFont(14, Color.BLACK);
					   tableBean.setThList(thList);  
					   
					   
							   //表格数据
							   List<List> bodyList = new ArrayList<List>(); //所有数据
							   List rowList = null; //行数据
							   if (scybyzzlList != null && scybyzzlList.size() > 0) {
								   for (YzwsInfo byzwx : scybyzzlList)  {
								    rowList = new ArrayList();
								    rowList.add( byzwx.getStrAn()); 
								    bodyList.add(rowList);
								   } 
							   }
							   
								if (sqrbyzzlList != null && sqrbyzzlList.size() > 0){
									for (YzwsInfo byzwx : sqrbyzzlList){
										    rowList = new ArrayList();
										    rowList.add(  byzwx.getStrAn() ); 
										    bodyList.add(rowList);
									}
								}
								
					   tableBean.setBodyList(bodyList);
					   Font bodyFont = ITextFontUtil.getCnFont(12, Color.BLACK);						  
					   Table table = PdfUtil.getTable(tableBean, thFont, bodyFont);  
					    elementList.add(PdfUtil.getPara ("被引证文献" , titleFont14)); 
						elementList.add(table);
				}
				
			}
	}
	
	
	public void insertLegalStatus(List<LegalStatusInfo> legalStatusInfoList , List elementList)
	{
		 /*法律状态*/
		   if(legalStatusInfoList!=null && legalStatusInfoList.size()>0)
		   {
			   
			 //表格
			   TableBean tableBean = new TableBean();
			   tableBean.setColumns(4);
			   List<String> thList = new ArrayList<String>();
			   thList.add("申请号");
			   thList.add("法律状态公告日");
			   thList.add("法律状态");
			   thList.add("法律状态信息");
			 
			   Font thFont = ITextFontUtil.getCnBoldFont(14, Color.BLACK);
			   tableBean.setThList(thList);  
			  
					   //表格数据
					   List<List> bodyList = new ArrayList<List>(); //所有数据
					   List rowList = null; //行数据
					   for (LegalStatusInfo legalStatusInfo : legalStatusInfoList)  
					   { 
					    rowList = new ArrayList();
					    rowList.add(legalStatusInfo.getStrAn());
					    rowList.add(legalStatusInfo.getStrLegalStatusDay());
					    rowList.add(legalStatusInfo.getStrLegalStatus());
					    rowList.add(legalStatusInfo.getStrStatusInfo());
					    bodyList.add(rowList);
					   }
			    
			   tableBean.setBodyList(bodyList);
			   Font bodyFont = ITextFontUtil.getCnFont(12, Color.BLACK);						  
			   Table table = PdfUtil.getTable(tableBean, thFont, bodyFont);  
			    elementList.add(PdfUtil.getPara ("法律状态" , titleFont14)); 
				elementList.add(table);
			  
		   }
	}
	
	
	public void init(DetailSearchResponse detailResponse)
	{ 
		pdfTempPath = PathUtil.getAbsoluteWebPath()+"temp/pdf/"+ UUID.randomUUID().toString() + "/";
		File pdfTempPathFile = new File(pdfTempPath);
		if(pdfTempPathFile.exists()==false)
			pdfTempPathFile.mkdirs();
		   //获得专利
	       patentInfo = detailResponse.getPatentInfo(); 
		  
		   pdfBean = new PdfBean();
		 //pdfBean.setHeader(patentInfo.getTi());
		   pdfBean.setFooter("知识产权出版社 ");
		   pdfBean.setFileName(pdfTempPath+patentInfo.getAn()+".pdf"); 
		   //fileNames.add(pdfTempPath+"测试"+i+".pdf");
		   elementList = new ArrayList();//元素 
		 //专利所在库
		   dbName = detailResponse.getSectionName(); 
	}
	
	public void makeZip(HttpServletResponse response,List fileNames)
	{
		 // 实例初始化
		JspFileDownload jfd = new JspFileDownload(); 
		// 设定response对象。
		jfd.setResponse(response);
		// 设定下载模式 1 多文件压缩成ZIP文件下载。
		jfd.setDownType(1);		
		// 设定显示的文件名
		jfd.setDisFileName(UUID.randomUUID().toString() + ".zip");
		// 设定要下载的文件的路径（数组，绝对路径）
		jfd.setZipFileNames(fileNames);
		// 设定服务器端生成的zip文件是否保留。 true 删除 false 保留，默认为false
		jfd.setZipDelFlag(true);
		// 设定zip文件暂时保存的路径 （是文件夹）
		jfd.setZipFilePath(pdfTempPath);
		// 主处理函数 注意返回值
		jfd.process();
		// 删除下载文件 
		Util.delFolder(pdfTempPath);
	}
	
	
	public void makeCNPDF(DetailSearchResponse detailResponse,List<LegalStatusInfo> legalStatusInfoList,
			String imageZhaiYaoURL , HttpServletResponse response)
	{  
			   Paragraph ti  = PdfUtil.getPara("名称："+patentInfo.getTi(),titleFont16); 			   
			   String zhuluxiangmu =   "申请（专利）号："+patentInfo.getAn() + br
				   					   + "申请日："+patentInfo.getAd() + br  
				   					   + "公开（公告）号："+patentInfo.getPn() + br	
				   					   + "公开（公告）日："+patentInfo.getPd() + br
				   					   + "主分类号："+patentInfo.getPic() + br
				   					   + "范畴分类："+patentInfo.getFcic()+ br
				   					   + "分类号："+patentInfo.getSic()+ br
				   					   + "优先权："+patentInfo.getPr()+ br
				   					   + "申请（专利权）人："+patentInfo.getPa() + br
				   					 + "地址："+patentInfo.getAr() + br
				   					 + "国省代码："+patentInfo.getCo() + br
				   					 + "发明（设计）人："+patentInfo.getPin() + br
				   					 + "国际申请："+patentInfo.getIan() + br
				   					 + "进入国家日期："+patentInfo.getDen() + br			   					
				   					 + "国际公布："+patentInfo.getIpn() + br
				   					 + "专利代理机构："+patentInfo.getAgc() + br
				   					 + "代理人："+patentInfo.getAgt() + br
				   					 + "分案申请号："+patentInfo.getDan() + br
				   					 + "颁证日：" + (patentInfo.getIpd()==null?"":patentInfo.getIpd()) + br 
				   					 + "主权项："+ br + space + patentInfo.getCl() + br 
				   					; 			  
			   Paragraph zhuluxiangPara  = PdfUtil.getPara (zhuluxiangmu  , normalFont); 
			   elementList.add(ti);
			   elementList.add(zhuluxiangPara); 
			 
			   /*摘要*/ 
			   this.insertZhaiyao(patentInfo,  elementList , imageZhaiYaoURL ); 
			   /*法律状态*/
			   this.insertLegalStatus(legalStatusInfoList, elementList);
			   /*引证文献*/
			   this.insertYZWX(detailResponse, elementList); 
			   
			    pdfBean.setElementList(elementList); 
			    Document doc = PdfUtil.buildDoc(true);
			    PdfUtil.exprotPdf(doc, pdfBean);
			    
			    ArrayList<String> fileNames = new ArrayList();  
			    fileNames.add(pdfTempPath+patentInfo.getAn()+".pdf"); 		
			    makeZip(response,fileNames);
		
		
		if(imageZhaiYaoURL != null)
			FileUtil.deleteFile(imageZhaiYaoURL);
	}
	
	public void makeWGPDF(DetailSearchResponse detailResponse,List<LegalStatusInfo> legalStatusInfoList,
			String imageZhaiYaoURL , HttpServletResponse response)
	{
		Paragraph ti  = PdfUtil.getPara("名称："+patentInfo.getTi(),titleFont16); 			   
		   String zhuluxiangmu =   "申请（专利）号："+patentInfo.getAn() + br
			   					   + "申请日："+patentInfo.getAd() + br  
			   					   + "公开（公告）号："+patentInfo.getPn() + br	
			   					   + "公开（公告）日："+patentInfo.getPd() + br
			   					   + "主分类号："+patentInfo.getPic() + br
			   					   + "范畴分类："+patentInfo.getFcic()+ br
			   					   + "分类号："+patentInfo.getSic()+ br
			   					   + "优先权："+patentInfo.getPr()+ br
			   					   + "申请（专利权）人："+patentInfo.getPa() + br
			   					 + "地址："+patentInfo.getAr() + br
			   					 + "国省代码："+patentInfo.getCo() + br
			   					 + "发明（设计）人："+patentInfo.getPin() + br
			   					 + "国际申请："+patentInfo.getIan() + br
			   					 + "进入国家日期："+patentInfo.getDen() + br			   					
			   					 + "国际公布："+patentInfo.getIpn() + br
			   					 + "专利代理机构："+patentInfo.getAgc() + br
			   					 + "代理人："+patentInfo.getAgt() + br
			   					 + "分案申请号："+patentInfo.getDan() + br
			   					 + "颁证日：" + (patentInfo.getIpd()==null?"":patentInfo.getIpd()) + br 
			   					 + "简要说明："+ br + space + patentInfo.getAb() + br 
			   					; 			  
		   Paragraph zhuluxiangPara  = PdfUtil.getPara (zhuluxiangmu  , normalFont); 
		   elementList.add(ti);
		   elementList.add(zhuluxiangPara); 
		 
		   
		   /*法律状态*/
		   this.insertLegalStatus(legalStatusInfoList, elementList);
		  
		   String tifServerURL = DataAccess.getProperty("PicServerURL");
		   String wgPicServerURL = DataAccess.getProperty("WGPicServerURL");
		   String WGTifServerURL = DataAccess.getProperty("WGTifServerURL");
		   if(WGTifServerURL==null)
		   	WGTifServerURL= "http://pic.cnipr.com:8080";
		   String pubPath = patentInfo.getTifDistributePath();		    
		   int tuNum = Integer.parseInt( patentInfo.getPages());	   
		   pubPath=pubPath.replace("\\","/"); 
		   String  ThumbnailImagePubPath = pubPath.toLowerCase().replaceAll("books",wgPicServerURL);
		   ThumbnailImagePubPath=ThumbnailImagePubPath.replace("/000001.tif","");
		   ThumbnailImagePubPath=ThumbnailImagePubPath+"/";
		   String TifPubPath = pubPath.substring(0,pubPath.lastIndexOf("/"));

		   TifPubPath = pubPath;
		   if(TifPubPath.indexOf(".tif")>-1){
		   	TifPubPath = TifPubPath.replace("/000001.tif","");
		   } 				
		   DecimalFormat df = new DecimalFormat("000000");
		   
		   Phrase title  =PdfUtil.getPhrase(br+"外观图形：" , titleFont14); 
		   elementList.add(title);
		   for(int i=0;i< tuNum ;i++)
		   {
			   Image img = null ;
			   String url = ThumbnailImagePubPath + df.format(i+1)+".jpg"; 
			    
				   img = PdfUtil.getImage(url, Image.LEFT, -1, -1);
				   img.scaleToFit(400, 400);
				   if(img!=null)
					   elementList.add(img); 
		   } 
		   
		    pdfBean.setElementList(elementList); 
		    Document doc = PdfUtil.buildDoc(true);
		    PdfUtil.exprotPdf(doc, pdfBean);
		    
		    ArrayList<String> fileNames = new ArrayList();  
		    fileNames.add(pdfTempPath+patentInfo.getAn()+".pdf"); 		
		    makeZip(response,fileNames);
	
	
	if(imageZhaiYaoURL != null)
		FileUtil.deleteFile(imageZhaiYaoURL);
	}
	
	
	public void makeSQPDF(DetailSearchResponse detailResponse,List<LegalStatusInfo> legalStatusInfoList,
			String imageZhaiYaoURL , HttpServletResponse response)
	{ 
		   Paragraph ti  = PdfUtil.getPara("名称："+patentInfo.getTi(),titleFont16); 			   
		   String  zhuluxiangmu = "申请（专利）号："+patentInfo.getAn() + br
									   + "申请日："+patentInfo.getAd() + br  
									   + "授权（公告）号："+patentInfo.getPnm() + br	
									   + "授权（公告）日："+patentInfo.getPd() + br
									   + "主分类号："+patentInfo.getPic() + br
									   + "范畴分类："+patentInfo.getFcic()+ br
									   + "分类号："+patentInfo.getSic()+ br
									   + "优先权："+patentInfo.getPr()+ br
									   + "申请（专利权）人："+patentInfo.getPa() + br
									 + "地址："+patentInfo.getAr() + br
									 + "国省代码："+patentInfo.getCo() + br
									 + "发明（设计）人："+patentInfo.getPin() + br
									 + "国际申请："+patentInfo.getIan() + br
									 + "进入国家日期："+patentInfo.getDen() + br			   					
									 + "国际公布："+patentInfo.getIpn() + br
									 + "专利代理机构："+patentInfo.getAgc() + br
									 + "代理人："+patentInfo.getAgt() + br
									 + "分案申请号："+patentInfo.getDan() + br
									 + "颁证日：" + (patentInfo.getIpd()==null?"":patentInfo.getIpd()) + br 
									 + "主权项："+ br + space + patentInfo.getCl() + br 
									;
		   Paragraph zhuluxiangPara  = PdfUtil.getPara (zhuluxiangmu  , normalFont); 
		   elementList.add(ti);
		   elementList.add(zhuluxiangPara); 
		 
		   /*摘要*/ 
		   this.insertZhaiyao(patentInfo,  elementList , imageZhaiYaoURL ); 
		   /*法律状态*/
		   this.insertLegalStatus(legalStatusInfoList, elementList);
		   /*引证文献*/
		   this.insertYZWX(detailResponse, elementList); 
		   
		    pdfBean.setElementList(elementList); 
		    Document doc = PdfUtil.buildDoc(true);
		    PdfUtil.exprotPdf(doc, pdfBean);
		    
		    ArrayList<String> fileNames = new ArrayList();  
		    fileNames.add(pdfTempPath+patentInfo.getAn()+".pdf"); 		
		    makeZip(response,fileNames); 
	
			if(imageZhaiYaoURL != null)
				FileUtil.deleteFile(imageZhaiYaoURL); 
	}
	
	
	
	
	
	public void makeFRPDF(DetailSearchResponse detailResponse,List<LegalStatusInfo> legalStatusInfoList,
			String imageZhaiYaoURL , HttpServletResponse response)
	{
		
		 Paragraph ti  = PdfUtil.getPara("名称："+patentInfo.getTi(),titleFont16); 			   
		   String zhuluxiangmu =   "申请（专利）号："+patentInfo.getAn() + br
			   					   + "申请日："+patentInfo.getAd() + br  
			   					   + "公开（公告）号："+patentInfo.getPn() + br	
			   					   + "公开（公告）日："+patentInfo.getPd() + br
			   					   + "主分类号："+patentInfo.getPic() + br 
			   					   + "分类号："+patentInfo.getSic()+ br
			   					 + "欧洲主分类号:"+ (patentInfo.getPec()==null?"":patentInfo.getPec()) + br
			   					 + "欧洲分类号:"+ (patentInfo.getSec()==null?"":patentInfo.getSec()) + br  
			   					   + "优先权："+patentInfo.getPr()+ br
			   					   + "申请（专利权）人："+patentInfo.getPa() + br   
			   					 + "发明（设计）人："+patentInfo.getPin() + br 
			   					 + "分案申请号："+patentInfo.getDan() + br
			   					 
			   					; 			  
		   Paragraph zhuluxiangPara  = PdfUtil.getPara (zhuluxiangmu  , normalFont); 
		   elementList.add(ti);
		   elementList.add(zhuluxiangPara); 
		 
		   
		   
		    pdfBean.setElementList(elementList); 
		    Document doc = PdfUtil.buildDoc(true);
		    PdfUtil.exprotPdf(doc, pdfBean);
		    
		    ArrayList<String> fileNames = new ArrayList();  
		    fileNames.add(pdfTempPath+patentInfo.getAn()+".pdf"); 		
		    makeZip(response,fileNames);
	
	}
	
	
	public  void  create(DetailSearchResponse detailResponse,List<LegalStatusInfo> legalStatusInfoList, String imageZhaiYaoURL , 
			HttpServletResponse response,String area){
		 init(detailResponse);  
		// System.out.println("dbName = "+dbName);
		 if(dbName.contains("fmsq"))
			 this.makeSQPDF(detailResponse, legalStatusInfoList, imageZhaiYaoURL, response);
		 else if(dbName.contains("wg"))
			 this.makeWGPDF(detailResponse, legalStatusInfoList, imageZhaiYaoURL, response);
		 else
			 if(dbName.contains("fmzl") || dbName.contains("syxx"))
				 this.makeCNPDF(detailResponse, legalStatusInfoList, imageZhaiYaoURL, response);
		 else 
		 if(area.equalsIgnoreCase("fr"))
			 this.makeFRPDF(detailResponse, null, null, response);
	}
}
