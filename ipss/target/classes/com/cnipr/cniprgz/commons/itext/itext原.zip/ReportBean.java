package com.cnipr.cniprgz.commons.itext;

import java.io.Serializable;

import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Table;

public class ReportBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2927407302626471756L;
	//标题
	private String title;
	//正文文字内容
	private Paragraph paragraph;
	//图片
	private Image image;
	//表格
	private Table table;
	//前摘要
	private Paragraph preSummary;
	//后摘要
	private Paragraph sufSummary;
	//图片名称
	private Paragraph imageName;
	//表格名称
	private Paragraph tableName;
	
	public ReportBean(){
		
	}
	public ReportBean(Paragraph paragraph,Image image){
		this.paragraph = paragraph;
		this.image = image;
	}
	public ReportBean(Paragraph paragraph,Image image,Table table){
		this.paragraph = paragraph;
		this.image = image;
		this.table = table;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Paragraph getParagraph() {
		return paragraph;
	}
	public void setParagraph(Paragraph paragraph) {
		this.paragraph = paragraph;
	}
	public Image getImage() {
		return image;
	}
	public void setImage(Image image) {
		this.image = image;
	}
	public Table getTable() {
		return table;
	}
	public void setTable(Table table) {
		this.table = table;
	}
	public Paragraph getPreSummary() {
		return preSummary;
	}
	public void setPreSummary(Paragraph preSummary) {
		this.preSummary = preSummary;
	}
	public Paragraph getSufSummary() {
		return sufSummary;
	}
	public void setSufSummary(Paragraph sufSummary) {
		this.sufSummary = sufSummary;
	}
	public Paragraph getImageName() {
		return imageName;
	}
	public void setImageName(Paragraph imageName) {
		this.imageName = imageName;
	}
	public Paragraph getTableName() {
		return tableName;
	}
	public void setTableName(Paragraph tableName) {
		this.tableName = tableName;
	}
	
}
