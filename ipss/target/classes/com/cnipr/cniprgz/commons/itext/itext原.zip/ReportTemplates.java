package com.cnipr.cniprgz.commons.itext;
import java.io.IOException;

import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.BaseFont;


public class ReportTemplates {

	public final static int TITLE_SIZE = 18;
	
	public final static int SIZE_14 = 14;
	
	public final static int SIZE_12 = 12;
	
	public final static int SIZE_10 = 10;
	
	public final static int SIZE_8 = 8;
	
	//设置中文字体
	private static BaseFont bfChinese = null;
	
	private ReportTemplates(){
		try {
			bfChinese = BaseFont.createFont("STSongStd-Light","UniGB-UCS2-H",BaseFont.NOT_EMBEDDED);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static ReportTemplates getInstance(){
		return new ReportTemplates();
	}
	
	public Paragraph getDefaultParagraph(String str){
		Paragraph para = new Paragraph(str);
		Font titleFont = new Font(bfChinese,SIZE_12,Font.NORMAL);
		para.setAlignment(Element.ALIGN_LEFT);
		para.setFont(titleFont);
		return para;
	}
}
