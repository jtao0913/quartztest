package com.cnipr.cniprgz.commons.itext;


import java.awt.Color;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.lowagie.text.Anchor;
import com.lowagie.text.Annotation;
import com.lowagie.text.Chapter;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Section;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;

import junit.framework.TestCase;

/**
* @author Jack Chang

* @version 創建時間：Jan 19, 2010 4:56:00 PM
* 類說明
*/



public class PdfUtilTest extends TestCase{


	public void testExportPdf(){
	   PdfUtil.exportPdf("你好hello", "d://1.pdf");
	}

	public void testExportPdf2(){
	   Font normalFont = ITextFontUtil.getCnFont(12, Color.RED);
	   Paragraph para = PdfUtil.getPara("你好， hello纰比纰比", normalFont);
	   PdfUtil.exportPdf(para, "d://pdf/中文2.pdf", false);
	}

	public void testExportPdf3(){
	   Font normalFont = ITextFontUtil.getCnFont(12, Color.RED);
	   Paragraph para = PdfUtil.getPara("你好， hello纰比纰比s", normalFont);
	   Document doc = PdfUtil.buildDoc(true);
	   boolean flag = doc.addTitle("title");
	   System.out.println(flag);
	//   doc = PdfUtil.setPdfProperty(doc, "title", "主题", "author", "keywords 1 , key2", "zd");
	   PdfUtil.exportPdf(doc, para, "d://pdf/中文3.pdf");
	}


	public void testExportPdf4(){
	   Font normalFont = ITextFontUtil.getCnFont(12, Color.RED);
	   Paragraph para = PdfUtil.getPara("你好， hello纰比纰比s", normalFont);
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setTitle("title===");
	   pdfBean.setAuthor("zd");
	   pdfBean.setSubject("xxx");
	   pdfBean.setKeywords("ke1, ke2");
	   pdfBean.setCreator("zdcreater");
	   pdfBean.setFileName("d://pdf/中文4.pdf");
	   List elementList = new ArrayList();
	   elementList.add(para);
	   pdfBean.setElementList(elementList);
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testExportPdfEncrypt(){
	   Font normalFont = ITextFontUtil.getCnFont(12, Color.RED);
	   Paragraph para = PdfUtil.getPara("你好， aaaa hello纰比纰比s", normalFont);
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setTitle("title===");
	   pdfBean.setAuthor("zd");
	   pdfBean.setSubject("xxx");
	   pdfBean.setKeywords("ke1, ke2");
	   pdfBean.setCreator("zdcreater");
	   pdfBean.setFileName("d://pdf//加密中文9.pdf");
	   List elementList = new ArrayList();
	   elementList.add(para);
	   pdfBean.setElementList(elementList);
	   //加密
	   pdfBean.setEncryptFlag(true);
	   pdfBean.setUserPsw("user");
	   pdfBean.setOwnerPsw("owner");
	   List permissionList = new ArrayList();
	   permissionList.add(PdfWriter.AllowScreenReaders);
	   pdfBean.setPermissionList(permissionList);
	   PdfUtil.exprotPdf(doc, pdfBean);
	}



	public void testExportPdfImg(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setFileName("d://pdf//image.pdf");
	   Image img = PdfUtil.getImage("d://image//81.gif", Image.ALIGN_MIDDLE, 100, 200);
	   List elementList = new ArrayList();
	   elementList.add(img);
	   pdfBean.setElementList(elementList);
	  
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testExportPdfHeaterFooter(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("PDF header ");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//image.pdf");
	   Image img = PdfUtil.getImage("d://image//81.gif", Image.ALIGN_MIDDLE, 100, 200);
	  
	   List elementList = new ArrayList();
	   elementList.add(img);
	   pdfBean.setElementList(elementList);
	  
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testExportPdfTable(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("表格测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//table.pdf");
	   //表格
	   TableBean tableBean = new TableBean();
	   tableBean.setColumns(3);
	   List<String> thList = new ArrayList<String>();
	   thList.add("No");
	   thList.add("Name");
	   thList.add("备注");
	   Font thFont = ITextFontUtil.getCnBoldFont(14, Color.BLACK);
	   tableBean.setThList(thList);  
	  
	   //表格数据
	   List<List> bodyList = new ArrayList<List>(); //所有数据
	   List rowList = null; //行数据
	   for(int i=1; i<=100; i++){
	    rowList = new ArrayList();
	    rowList.add("id-" + i);
	    rowList.add("Name-" + i);
	    rowList.add("备注-" + i);
	    bodyList.add(rowList);
	   }
	   tableBean.setBodyList(bodyList);
	   Font bodyFont = ITextFontUtil.getCnFont(12, Color.BLACK);
	  
	   Table table = PdfUtil.getTable(tableBean, thFont, bodyFont);  
	   List elementList = new ArrayList();
	   elementList.add(table);
	   pdfBean.setElementList(elementList);
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testPhrase(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("Phrase测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//phrase.pdf");  
	   Font font = ITextFontUtil.getCnFont(12, Color.BLACK);
	   Phrase phrase = PdfUtil.getPhrase("Phrase测试,Phrase测试,Phrase测试", font); 
	   Phrase phrase2 = PdfUtil.getPhrase("Phrase2测试,Phrase测试2,Phrase测试2", font); 
	   List elementList = new ArrayList();
	   elementList.add(phrase);
	   elementList.add(phrase2);
	   pdfBean.setElementList(elementList); 
	   PdfUtil.exprotPdf(doc, pdfBean);
	}

	public void testParagraph(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("Phrase测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//paragraph.pdf");  
	   Font font = ITextFontUtil.getCnFont(12, Color.BLACK);
	   Paragraph para = PdfUtil.getPara("Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	   Paragraph para2 = PdfUtil.getPara("xxxxPhrase2测试,Phrase测试2,Phrase测试2Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	   List elementList = new ArrayList();
	   elementList.add(para);
	   elementList.add(para2);
	   pdfBean.setElementList(elementList); 
	   PdfUtil.exprotPdf(doc, pdfBean);
	}

	public void testAnchor(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("Anchor测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//Anchor.pdf");  
	   Font font = ITextFontUtil.getCnUnderlineFont(12,Color.BLUE); //下划线蓝色
	   Anchor anchor = PdfUtil.getAnchor("百度", font, "http://www.baidu.com");
	   List elementList = new ArrayList();
	   elementList.add(anchor);
	   pdfBean.setElementList(elementList); 
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testPdfList(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("List测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//List.pdf");  
	   Font font = ITextFontUtil.getCnFont(12,Color.BLUE); //下划线蓝色
	   List list = new ArrayList();
	   String temp = "=China 中国-";
	   for(int i=1; i<5; i++){
	    list.add(temp);
	    temp = temp + i;   
	   }
	   com.lowagie.text.List padList = PdfUtil.getPdfList(list, false, 20, font);
	   padList.setListSymbol("*");
	   List elementList = new ArrayList();
	   elementList.add(padList);
	   pdfBean.setElementList(elementList); 
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testAnnotation(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("Annotation测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//Annotation.pdf");  
	   Font font = ITextFontUtil.getCnFont(12, Color.BLACK);
	   Paragraph para = PdfUtil.getPara("Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	   Paragraph para2 = PdfUtil.getPara("xxxxPhrase2测试,Phrase测试2,Phrase测试2Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	  
	   Annotation anno2 = PdfUtil.getAnnotation("日期", "中巴中巴中巴中中巴中巴中巴中巴中巴中中巴中巴中" +
	     "巴中巴中巴中中巴中巴中巴中巴中巴中中巴中巴中巴中巴中巴中中巴中巴中巴中巴中巴中中" +
	     "巴中巴中巴中巴中巴中中巴中巴中巴中巴中巴中中巴中巴中巴中巴中巴中中巴中巴" +
	     "中巴中巴中巴中中巴中巴中巴中巴中巴中中巴中巴中巴中巴中巴中巴中巴中巴", 300f, 600f);
	   List elementList = new ArrayList();
	   elementList.add(para);  
	   elementList.add(para2);
	   elementList.add(anno2);
	   pdfBean.setElementList(elementList); 
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testAnnotationUrl(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("Annotation测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//Annotation2.pdf");  
	   Font font = ITextFontUtil.getCnFont(12, Color.BLACK);
	   Paragraph para = PdfUtil.getPara("Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	   Paragraph para2 = PdfUtil.getPara("xxxxPhrase2测试,Phrase测试2,Phrase测试2Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	  
	   Annotation anno2 = PdfUtil.getAnnotationUrl(100f, 700f, 200f, 800f,"http://www.baidu.com");
	   List elementList = new ArrayList();
	   elementList.add(para);  
	   elementList.add(para2);
	   elementList.add(anno2);
	   pdfBean.setElementList(elementList); 
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testChapter(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("Annotation测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//chapter.pdf");  
	   Font font = ITextFontUtil.getCnFont(12, Color.BLACK);
	   Paragraph para = PdfUtil.getPara("Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	   Paragraph para2 = PdfUtil.getPara("xxxxPhrase2测试,Phrase测试2,Phrase测试2Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	   Chapter chapter = PdfUtil.getChapter("章节", font, 1);
	   Chapter chapter2 = PdfUtil.getChapter("章节", font, 2);

	   List elementList = new ArrayList();
	   elementList.add(para);  
	   elementList.add(para2);
	   elementList.add(chapter);
	   elementList.add(chapter2);
	   pdfBean.setElementList(elementList); 
	   PdfUtil.exprotPdf(doc, pdfBean);
	}


	public void testSection(){
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("Annotation测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//section.pdf");  
	   Font font = ITextFontUtil.getCnFont(12, Color.BLACK);
	   Paragraph para = PdfUtil.getPara("Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	   Paragraph para2 = PdfUtil.getPara("xxxxPhrase2测试,Phrase测试2,Phrase测试2Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试Phrase测试,Phrase测试,Phrase测试", font); 
	   Chapter chapter = PdfUtil.getChapter("章节", font, 1);
	        Section section = PdfUtil.getSection(chapter, "块===1", font, 1);
	        section.add(para);
	        Section section2 = PdfUtil.getSection(chapter, "块====2", font, 1);
	        section2.add(para2);
	        Section section3 = PdfUtil.getSection(chapter, "块====3", font, 2);

	   List elementList = new ArrayList();
	   elementList.add(chapter);
	   pdfBean.setElementList(elementList); 
	   PdfUtil.exprotPdf(doc, pdfBean);
	}






	public void test(){
		
	   Paragraph title2 = new Paragraph("This is Chapter 2", FontFactory.getFont(FontFactory.HELVETICA, 18, Font.BOLDITALIC, new Color(0, 0, 255)));
	   Chapter chapter2 = new Chapter(title2, 2);
	   Paragraph someText = new Paragraph("This is some text");
	   chapter2.add(someText);
	   Paragraph title21 = new Paragraph("This is Section 1 in Chapter 2", FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD, new Color(255, 0, 0)));
	   Section section1 = chapter2.addSection(title21);
	   Paragraph someSectionText = new Paragraph("This is some silly paragraph in a chapter and/or section. It contains some text to test the functionality of Chapters and Section.");
	   section1.add(someSectionText);
	   Paragraph title211 = new Paragraph("This is SubSection 1 in Section 1 in Chapter 2", FontFactory.getFont(FontFactory.HELVETICA, 14, Font.BOLD, new Color(255, 0, 0)));
	   Section section11 = section1.addSection(40, title211, 2);
	   section11.add(someSectionText);
	   
	   
	   Document doc = PdfUtil.buildDoc(true);
	   PdfBean pdfBean = new PdfBean();
	   pdfBean.setHeader("Annotation测试");
	   pdfBean.setFooter("Page ");
	   pdfBean.setFileName("d://pdf//testpdf.pdf"); 
	   List elementList = new ArrayList();
	    elementList.add(chapter2);
	    pdfBean.setElementList(elementList); 
	    PdfUtil.exprotPdf(doc, pdfBean);

	    }

}