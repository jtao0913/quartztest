package com.cnipr.cniprgz.commons.itext;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lowagie.text.Element;

/**
* @author Jack Chang
* @version 創建時間：Jan 20, 2010 11:15:48 AM
* 類說明:Pdf信息
*/
public class PdfBean implements Serializable{

private static final long serialVersionUID = -457346454899043721L; //implements Serializable序列化，用于网络传输时，会用到。若是单机，就没用

//pdf属性
 
private String title;//标题
private String subject; //主题
private String keywords; //关键词
private String author; //作者
private String creator; //创建人
private Map headerMap;//对于pdf文档无效，doc.addHeader()仅对html文档有效，用于添加文档的头信息


//最重要的
private List<Element> elementList; //元素List
private String fileName;//pdf文件名

//页头和页尾
private String header;//页头
private String footer;//页尾

//以下是加密
private boolean encryptFlag = false; //是否加密;
private String userPsw; //用户密码 null 或 "" 不用密码
private String ownerPsw; //作者密码 null 或 "" 不用密码
private List permissionList; //权限列表 ,参考PdfWriter常量 如：ALLOW_COPY

public PdfBean() {

}
    
/**
* html时用到
* @param headerMap
*/
public PdfBean(Map headerMap) {
   headerMap.put("Expires", 0); 
   this.headerMap = headerMap;
	}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getSubject() {
	return subject;
}

public void setSubject(String subject) {
	this.subject = subject;
}

public String getKeywords() {
	return keywords;
}

public void setKeywords(String keywords) {
	this.keywords = keywords;
}

public String getAuthor() {
	return author;
}

public void setAuthor(String author) {
	this.author = author;
}

public String getCreator() {
	return creator;
}

public void setCreator(String creator) {
	this.creator = creator;
}

public Map getHeaderMap() {
	return headerMap;
}

public void setHeaderMap(Map headerMap) {
	this.headerMap = headerMap;
}

public List<Element> getElementList() {
	return elementList;
}

public void setElementList(List<Element> elementList) {
	this.elementList = elementList;
}

public String getFileName() {
	return fileName;
}

public void setFileName(String fileName) {
	this.fileName = fileName;
}

public String getHeader() {
	return header;
}

public void setHeader(String header) {
	this.header = header;
}

public String getFooter() {
	return footer;
}

public void setFooter(String footer) {
	this.footer = footer;
}

public boolean isEncryptFlag() {
	return encryptFlag;
}

public void setEncryptFlag(boolean encryptFlag) {
	this.encryptFlag = encryptFlag;
}

public String getUserPsw() {
	return userPsw;
}

public void setUserPsw(String userPsw) {
	this.userPsw = userPsw;
}

public String getOwnerPsw() {
	return ownerPsw;
}

public void setOwnerPsw(String ownerPsw) {
	this.ownerPsw = ownerPsw;
}

public List getPermissionList() {
	return permissionList;
}

public void setPermissionList(List permissionList) {
	this.permissionList = permissionList;
}

 
}