package com.echarts.code;

/**
 * 特效类型
 *
 * @author liuzh
 * @since 2016-02-28 10:33
 */
public enum EffectType {
    ripple //涟漪特效
}
